package com.fuat.urunhafizam;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout list; EditText search;
    final int green=0xFF176B50, dark=0xFF12533E, pale=0xFFF2F7F4;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); showHome();}
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(-1);b.setBackground(bg(green,12));return b;}
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(bg(0xFFF0F2F1,10));return e;}
    void base(String title){LinearLayout root=column();root.setBackgroundColor(pale);TextView head=text(title,24,-1,true);head.setPadding(dp(18),dp(20),dp(18),dp(20));head.setBackgroundColor(green);root.addView(head);setContentView(root);}
    void showHome(){
        LinearLayout root=column();root.setBackgroundColor(pale);
        TextView head=text("Market",25,-1,true);head.setPadding(dp(20),dp(22),dp(16),dp(8));head.setBackgroundColor(green);root.addView(head);
        TextView sub=text("En ucuz nereden alıyordum?",14,0xFFE0EEE7,false);sub.setPadding(dp(20),0,dp(16),dp(18));sub.setBackgroundColor(green);root.addView(sub);
        LinearLayout body=column();body.setPadding(dp(16),dp(14),dp(16),dp(12));root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        search=field("Ürün veya marka ara...");body.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout actions=row();actions.setPadding(0,dp(10),0,dp(10));Button add=button("+ Ürün ekle");actions.addView(add,new LinearLayout.LayoutParams(0,dp(48),1));body.addView(actions);add.setOnClickListener(v->editItem(null));
        TextView count=text("KAYITLI ÜRÜNLER",12,0xFF53645B,true);count.setPadding(dp(2),dp(8),0,dp(8));body.addView(count);
        ScrollView scroll=new ScrollView(this);list=column();scroll.addView(list);body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int start,int before,int count){loadItems(s.toString());}public void afterTextChanged(Editable e){}});
        setContentView(root);loadItems("");
    }
    void loadItems(String q){if(list==null)return;list.removeAllViews();Cursor c=db.getReadableDatabase().rawQuery("SELECT * FROM products WHERE name LIKE ? OR brand LIKE ? OR store LIKE ? ORDER BY name COLLATE NOCASE",new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"});
        if(c.getCount()==0){TextView empty=text("Henüz ürün yok. Ürün ekle düğmesine dokun.",15,0xFF607168,false);empty.setPadding(dp(8),dp(24),dp(8),dp(24));list.addView(empty);}
        while(c.moveToNext()){final Item it=new Item(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6));LinearLayout card=column();card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(bg(-1,14));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(10);list.addView(card,cp);
            TextView name=text(it.name,18,0xFF1D3028,true);card.addView(name);String meta=(it.brand.isEmpty()?"":it.brand+"  ·  ")+(it.amount.isEmpty()?"":it.amount);if(!meta.isEmpty())card.addView(text(meta,14,0xFF63746B,false));
            card.addView(text(it.price.isEmpty()?"Fiyat girilmedi":it.price+" TL",21,green,true));if(!it.store.isEmpty())card.addView(text("Mağaza: "+it.store,14,0xFF53645B,false));if(!it.note.isEmpty())card.addView(text("Not: "+it.note,13,0xFF63746B,false));
            LinearLayout buttons=row();buttons.setGravity(Gravity.RIGHT);Button edit=button("Düzenle");Button del=new Button(this);del.setText("Sil");del.setAllCaps(false);del.setTextColor(0xFFB3261E);buttons.addView(edit);buttons.addView(del);card.addView(buttons);edit.setOnClickListener(v->editItem(it));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Ürünü sil?").setMessage(it.name+" kaydı silinecek.").setNegativeButton("Vazgeç",null).setPositiveButton("Sil",(d,w)->{db.getWritableDatabase().delete("products","id=?",new String[]{""+it.id});loadItems(search==null?"":search.getText().toString());}).show());
        }c.close();}
    static class Item{long id;String name,brand,amount,price,store,note;Item(long i,String n,String b,String a,String p,String s,String no){id=i;name=n;brand=b;amount=a;price=p;store=s;note=no;}}
    void editItem(Item item){
        LinearLayout form=column();form.setPadding(dp(8),dp(4),dp(8),dp(4));ScrollView sc=new ScrollView(this);sc.addView(form);
        EditText name=field("Ürün adı *"),brand=field("Marka"),amount=field("Miktar (örn. 1 kg, 5 litre, 12 adet)"),price=field("Fiyat (TL)"),store=field("Mağaza / internet sitesi"),note=field("Not");
        EditText[] fields={name,brand,amount,price,store,note};String[] vals=item==null?new String[]{"","","","","",""}:new String[]{item.name,item.brand,item.amount,item.price,item.store,item.note};String[] labels={"Ürün adı","Marka","Miktar","Fiyat","Mağaza","Not"};
        for(int i=0;i<fields.length;i++){TextView label=text(labels[i],13,0xFF53645B,true);label.setPadding(dp(2),dp(7),0,dp(3));form.addView(label);fields[i].setText(vals[i]);form.addView(fields[i],new LinearLayout.LayoutParams(-1,dp(48)));}
        if(item!=null)price.setInputType(8194);else price.setInputType(8194);
        new AlertDialog.Builder(this).setTitle(item==null?"Yeni ürün":"Ürünü düzenle").setView(sc).setNegativeButton("İptal",null).setPositiveButton("Kaydet",(dialog,which)->{String n=name.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"Ürün adı gerekli.",Toast.LENGTH_SHORT).show();return;}String[] v=new String[6];for(int i=0;i<6;i++)v[i]=fields[i].getText().toString().trim();if(item==null)db.insert(v);else db.update(item.id,v);hideKeyboard();loadItems(search==null?"":search.getText().toString());Toast.makeText(this,"Ürün kaydedildi",Toast.LENGTH_SHORT).show();}).show();
    }
    void hideKeyboard(){try{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),0);}catch(Exception ignored){}}
    static class DB extends SQLiteOpenHelper{DB(Context c){super(c,"urun_hafizam.db",null,1);}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,brand TEXT,amount TEXT,price TEXT,store TEXT,note TEXT)");}public void onUpgrade(SQLiteDatabase d,int o,int n){}void insert(String[] v){ContentValues c=cv(v);getWritableDatabase().insert("products",null,c);}void update(long id,String[] v){getWritableDatabase().update("products",cv(v),"id=?",new String[]{""+id});}ContentValues cv(String[] v){ContentValues c=new ContentValues();String[] k={"name","brand","amount","price","store","note"};for(int i=0;i<k.length;i++)c.put(k[i],v[i]);return c;}}
}
