package com.fuat.urunhafizam;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputFilter;
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final int REQUEST_CREATE_BACKUP=4101, REQUEST_RESTORE_BACKUP=4102;
    DB db; LinearLayout list; EditText search; int sortColumn=0; boolean sortAscending=true;
    final int green=0xFF176B50, dark=0xFF12533E, pale=0xFFF2F7F4;
    int calcUnit=0; int listFontMode=1; EditText calcAmount, calcPrice; TextView kgResult, gramResult, adetResult, calcAmountLabel; LinearLayout calculatorRoot; boolean calculatorShown=false;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); listFontMode=getSharedPreferences("marketim_ui",MODE_PRIVATE).getInt("list_font_mode",1); showHome();}
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(-1);b.setBackground(bg(green,12));return b;}
    static String normalizeText(String value){
        if(value==null)return "";
        return value.replace('ç','C').replace('Ç','C')
                .replace('ş','S').replace('Ş','S')
                .replace('ğ','G').replace('Ğ','G')
                .replace('ö','O').replace('Ö','O')
                .replace('ü','U').replace('Ü','U')
                .replace('i','I').replace('İ','I').replace('ı','I').replace('I','I')
                .toUpperCase(Locale.ROOT);
    }
    void applyTextNormalization(EditText e){
        e.addTextChangedListener(new TextWatcher(){
            boolean changing=false;
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(Editable editable){
                if(changing)return;
                String original=editable.toString();
                String normalized=normalizeText(original);
                if(!original.equals(normalized)){
                    int cursor=e.getSelectionStart();
                    changing=true;e.setText(normalized);
                    e.setSelection(Math.min(Math.max(cursor,0),normalized.length()));
                    changing=false;
                }
            }
        });
    }
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(bg(0xFFF0F2F1,10));applyTextNormalization(e);return e;}
    void base(String title){LinearLayout root=column();root.setBackgroundColor(pale);TextView head=text(title,24,-1,true);head.setPadding(dp(18),dp(20),dp(18),dp(20));head.setBackgroundColor(green);root.addView(head);setContentView(root);}
    void showHome(){
        calculatorShown=false;
        LinearLayout root=column(); root.setBackgroundColor(pale);
        LinearLayout header=column(); header.setPadding(dp(18),dp(14),dp(18),dp(8)); header.setBackgroundColor(0xFFFFFFFF);
        LinearLayout brandRow=row();
        TextView head=text("Marketim",30,green,true); brandRow.addView(head);
        ImageView basket=new ImageView(this); basket.setImageResource(com.fuat.urunhafizam.R.drawable.ic_basket);
        LinearLayout.LayoutParams basketParams=new LinearLayout.LayoutParams(dp(38),dp(38)); basketParams.leftMargin=dp(8); brandRow.addView(basket,basketParams);
        View headerSpacer=new View(this); brandRow.addView(headerSpacer,new LinearLayout.LayoutParams(0,1,1));
        TextView menuButton=text("⋮",30,green,true); menuButton.setGravity(Gravity.CENTER); menuButton.setPadding(dp(8),0,dp(4),0);
        brandRow.addView(menuButton,new LinearLayout.LayoutParams(dp(42),dp(42)));
        menuButton.setOnClickListener(v->showMainMenu(menuButton)); header.addView(brandRow);
        TextView email=text("fuat25erkan@gmail.com",11,0xFF63746B,false); email.setGravity(Gravity.RIGHT); header.addView(email); root.addView(header);
        LinearLayout body=column(); body.setPadding(dp(12),dp(12),dp(12),dp(10)); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout searchActions=row(); searchActions.setGravity(Gravity.CENTER_VERTICAL);
        search=field("Ürün veya marka ara..."); search.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0); search.setCompoundDrawablePadding(dp(8));
        searchActions.addView(search,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView add=actionTile("plus",0xFFFF9D24,-1,54); LinearLayout.LayoutParams addParams=new LinearLayout.LayoutParams(dp(54),dp(48));addParams.leftMargin=dp(6);searchActions.addView(add,addParams);add.setContentDescription("Ürün ekle"); add.setOnClickListener(v->editItem(null));
        TextView calc=actionTile("calculator",0xFF16844E,-1,54); LinearLayout.LayoutParams calcParams=new LinearLayout.LayoutParams(dp(54),dp(48));calcParams.leftMargin=dp(6);searchActions.addView(calc,calcParams);calc.setContentDescription("Hesap makinesi"); calc.setOnClickListener(v->showCalculator());
        body.addView(searchActions);
        String[] labels={"ÜRÜN","MARKA","MAĞAZA","FİYAT (TL/kg)","İŞLEM"};
        LinearLayout headings=row(); headings.setBackground(bg(green,10)); headings.setPadding(dp(3),dp(12),dp(3),dp(12));
        float[] weights={1.15f,0.82f,0.88f,0.95f,0.68f};
        for(int i=0;i<labels.length;i++){ final int col=i; TextView t=text(labels[i],listFontMode==0?10:listFontMode==1?12:14,-1,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(1),0,dp(1),0);headings.addView(t,new LinearLayout.LayoutParams(0,-2,weights[i]));t.setOnClickListener(v->{if(col<4){sortColumn=col;sortAscending=!sortAscending;loadItems(search==null?"":search.getText().toString());}}); }
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(10); hp.bottomMargin=dp(6); body.addView(headings,hp);
        ScrollView vertical=new ScrollView(this); vertical.setFillViewport(false); vertical.setVerticalScrollBarEnabled(true); vertical.setClipToPadding(false);
        list=column(); vertical.addView(list,new ScrollView.LayoutParams(-1,-2)); body.addView(vertical,new LinearLayout.LayoutParams(-1,0,1));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int start,int before,int count){loadItems(s.toString());}public void afterTextChanged(Editable e){}});
        setContentView(root); loadItems("");
    }
    TextView actionTile(String label,int color,int textColor,int width){ActionTileView t=new ActionTileView(this,label,color);t.setBackground(bg(color,14));t.setElevation(dp(4));return t;}
    class ActionTileView extends TextView{final String kind;final int color;final android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);ActionTileView(Context c,String k,int col){super(c);kind=k;color=col;setGravity(Gravity.CENTER);setClickable(true);setFocusable(true);setText("");} @Override protected void onDraw(android.graphics.Canvas c){super.onDraw(c);float sx=getWidth()/54f,sy=getHeight()/48f;c.save();c.scale(sx,sy);c.translate(27,24);c.scale(0.78f,0.78f);c.translate(-27,-24);p.setColor(0xFFFFFFFF);p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(3.6f);p.setStrokeCap(android.graphics.Paint.Cap.ROUND);p.setStrokeJoin(android.graphics.Paint.Join.ROUND);if(kind.equals("plus")){c.drawLine(27,16,27,32,p);c.drawLine(19,24,35,24,p);}else{c.drawRoundRect(17,6,37,42,3,3,p);c.drawRoundRect(20,10,34,17,1,1,p);p.setStyle(android.graphics.Paint.Style.FILL);float[] xs={21,27,33},ys={23,29,35};for(int r=0;r<3;r++)for(int col=0;col<3;col++)c.drawRoundRect(xs[col]-1.4f,ys[r]-1.4f,xs[col]+1.4f,ys[r]+1.4f,1,1,p);}c.restore();}}
    void showMainMenu(View anchor){
        PopupMenu popup=new PopupMenu(this,anchor);
        popup.getMenu().add(0,1,0,"Yedekle");
        popup.getMenu().add(0,2,1,"Yedekten geri yükle");
        popup.getMenu().add(0,3,2,"Yazı boyutu");
        popup.setOnMenuItemClickListener(item->{
            if(item.getItemId()==1){startBackupPicker();return true;}
            if(item.getItemId()==2){startRestorePicker();return true;}
            if(item.getItemId()==3){showFontSizeDialog();return true;}
            return false;
        });
        popup.show();
    }
    void showFontSizeDialog(){
        String[] sizes={"Küçük","Normal","Büyük"};
        new AlertDialog.Builder(this).setTitle("Liste yazı boyutu")
            .setSingleChoiceItems(sizes,listFontMode,(dialog,which)->{
                listFontMode=which;getSharedPreferences("marketim_ui",MODE_PRIVATE).edit().putInt("list_font_mode",which).apply();
                loadItems(search==null?"":search.getText().toString());dialog.dismiss();
            }).setNegativeButton("Kapat",null).show();
    }
    void startBackupPicker(){
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.ROOT).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE,"Marketim_Yedek_"+stamp+".json");
        try{startActivityForResult(intent,REQUEST_CREATE_BACKUP);}
        catch(ActivityNotFoundException e){Toast.makeText(this,"Dosya kaydetmek için kullanılabilir bir dosya yöneticisi bulunamadı.",Toast.LENGTH_LONG).show();}
    }
    void startRestorePicker(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        try{startActivityForResult(intent,REQUEST_RESTORE_BACKUP);}
        catch(ActivityNotFoundException e){Toast.makeText(this,"Yedek seçmek için kullanılabilir bir dosya yöneticisi bulunamadı.",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri=data.getData();
        if(requestCode==REQUEST_CREATE_BACKUP){
            try{writeBackup(uri);Toast.makeText(this,"Yedek başarıyla kaydedildi.",Toast.LENGTH_LONG).show();}
            catch(Exception e){Toast.makeText(this,"Yedek oluşturulamadı: "+safeMessage(e),Toast.LENGTH_LONG).show();}
        }else if(requestCode==REQUEST_RESTORE_BACKUP){
            try{
                JSONObject backup=readBackup(uri);
                JSONArray products=backup.optJSONArray("products");
                if(products==null)throw new Exception("Yedek dosyasında ürün listesi bulunamadı.");
                for(int i=0;i<products.length();i++){
                    JSONObject product=products.optJSONObject(i);
                    if(product==null || product.optString("name").trim().isEmpty())throw new Exception("Yedek dosyasında geçersiz ürün kaydı var.");
                }
                new AlertDialog.Builder(this)
                    .setTitle("Yedeği geri yükle?")
                    .setMessage(products.length()+" ürün geri yüklenecek. Mevcut ürün listen yedekteki listeyle değiştirilecek.")
                    .setNegativeButton("Vazgeç",null)
                    .setPositiveButton("Geri yükle",(dialog,which)->{
                        try{restoreProducts(products);loadItems(search==null?"":search.getText().toString());Toast.makeText(this,"Yedek başarıyla geri yüklendi.",Toast.LENGTH_LONG).show();}
                        catch(Exception e){Toast.makeText(this,"Geri yükleme başarısız: "+safeMessage(e),Toast.LENGTH_LONG).show();}
                    }).show();
            }catch(Exception e){Toast.makeText(this,"Yedek okunamadı: "+safeMessage(e),Toast.LENGTH_LONG).show();}
        }
    }
    void writeBackup(Uri uri) throws Exception{
        JSONObject backup=new JSONObject();
        backup.put("app","Marketim");
        backup.put("formatVersion",1);
        backup.put("createdAt",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ",Locale.ROOT).format(new Date()));
        JSONArray products=new JSONArray();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,brand,amount,price,store,note FROM products ORDER BY id ASC",null);
        try{
            while(c.moveToNext()){
                JSONObject product=new JSONObject();
                product.put("id",c.getLong(0));
                product.put("name",nullToEmpty(c.getString(1)));
                product.put("brand",nullToEmpty(c.getString(2)));
                product.put("amount",nullToEmpty(c.getString(3)));
                product.put("price",nullToEmpty(c.getString(4)));
                product.put("store",nullToEmpty(c.getString(5)));
                product.put("note",nullToEmpty(c.getString(6)));
                products.put(product);
            }
        }finally{c.close();}
        backup.put("products",products);
        OutputStream out=getContentResolver().openOutputStream(uri);
        if(out==null)throw new IOException("Dosya yazmak için açılamadı.");
        try(Writer writer=new OutputStreamWriter(out,"UTF-8")){writer.write(backup.toString(2));writer.flush();}
    }
    JSONObject readBackup(Uri uri) throws Exception{
        InputStream in=getContentResolver().openInputStream(uri);
        if(in==null)throw new IOException("Dosya açılamadı.");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(InputStream input=in){byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1){bytes.write(buffer,0,count);if(bytes.size()>10*1024*1024)throw new IOException("Yedek dosyası çok büyük.");}}
        String json=new String(bytes.toByteArray(),"UTF-8");
        JSONObject backup=new JSONObject(json);
        if(!"Marketim".equals(backup.optString("app")) || backup.optInt("formatVersion",0)!=1)throw new Exception("Bu dosya geçerli bir Marketim yedeği değil.");
        return backup;
    }
    void restoreProducts(JSONArray products) throws Exception{
        SQLiteDatabase database=db.getWritableDatabase();
        database.beginTransaction();
        try{
            database.delete("products",null,null);
            for(int i=0;i<products.length();i++){
                JSONObject product=products.getJSONObject(i);
                ContentValues values=new ContentValues();
                long id=product.optLong("id",0);
                if(id>0)values.put("id",id);
                values.put("name",normalizeText(product.optString("name")));
                values.put("brand",normalizeText(product.optString("brand")));
                values.put("amount",product.optString("amount"));
                values.put("price",product.optString("price"));
                values.put("store",normalizeText(product.optString("store")));
                values.put("note",normalizeText(product.optString("note")));
                if(database.insertOrThrow("products",null,values)==-1)throw new Exception("Bir ürün kaydedilemedi.");
            }
            database.setTransactionSuccessful();
        }finally{database.endTransaction();}
    }
    String nullToEmpty(String value){return value==null?"":value;}
    String safeMessage(Exception e){String m=e.getMessage();return m==null?"Bilinmeyen hata":m;}
    void loadItems(String q){
        if(list==null)return; while(list.getChildCount()>0)list.removeViewAt(0);
        String[] order={"name COLLATE NOCASE","brand COLLATE NOCASE","store COLLATE NOCASE","CAST(price AS REAL)"};
        String direction=sortAscending?" ASC":" DESC";
        Cursor c=db.getReadableDatabase().rawQuery("SELECT * FROM products WHERE name LIKE ? OR brand LIKE ? OR store LIKE ? ORDER BY "+order[sortColumn]+direction+", name COLLATE NOCASE ASC",new String[]{"%"+normalizeText(q)+"%","%"+normalizeText(q)+"%","%"+normalizeText(q)+"%"});
        if(c.getCount()==0){TextView empty=text("Henüz ürün yok. + düğmesine dokunarak ürün ekleyin.",14,0xFF607168,false);empty.setPadding(dp(8),dp(20),dp(8),dp(20));list.addView(empty);}
        float[] weights={1.15f,0.82f,0.88f,0.95f,0.62f};
        while(c.moveToNext()){
            final Item it=new Item(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6));
            LinearLayout card=row(); card.setBackground(bg(-1,14)); card.setElevation(dp(2)); card.setPadding(dp(5),dp(8),dp(5),dp(8));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(6);list.addView(card,cp);
            String[] vals={normalizeText(it.name),normalizeText(it.brand),normalizeText(it.store),it.price.isEmpty()?"—":fmt(number(it.price))+" TL/kg"};
            for(int i=0;i<vals.length;i++){TextView t=text(vals[i]==null?"":vals[i],listFontMode==0?10:listFontMode==1?12:14,i==3?green:0xFF1D3028,i==0||i==3);t.setGravity(Gravity.CENTER);t.setPadding(dp(1),dp(3),dp(1),dp(3));card.addView(t,new LinearLayout.LayoutParams(0,-2,weights[i]));}
            LinearLayout buttons=column();buttons.setGravity(Gravity.CENTER);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,weights[4]);
            View edit=iconAction("edit",0xFF167BE0); View del=iconAction("delete",0xFFD92D27);
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(29));buttons.addView(edit,ep);LinearLayout.LayoutParams delp=new LinearLayout.LayoutParams(-1,dp(29));delp.topMargin=dp(3);buttons.addView(del,delp);card.addView(buttons,bp);
            edit.setOnClickListener(v->editItem(it));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Ürünü sil?").setMessage(it.name+" kaydı silinecek.").setNegativeButton("Vazgeç",null).setPositiveButton("Sil",(d,w)->{db.getWritableDatabase().delete("products","id=?",new String[]{""+it.id});loadItems(search==null?"":search.getText().toString());}).show());
        }c.close();
    }
    View iconAction(String glyph,int color){ActionIconView v=new ActionIconView(this,glyph,color);v.setElevation(dp(3));return v;}
    class ActionIconView extends View{
        final String kind; final int color; final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        ActionIconView(Context context,String kind,int color){super(context);this.kind=kind;this.color=color;setClickable(true);setFocusable(true);}
        @Override protected void onDraw(android.graphics.Canvas canvas){super.onDraw(canvas);float sx=getWidth()/64f,sy=getHeight()/48f;canvas.save();canvas.scale(sx,sy);
            paint.setStyle(android.graphics.Paint.Style.FILL);paint.setColor(color);canvas.drawRoundRect(2,2,62,46,9,9,paint);
            paint.setColor(0xFFFFFFFF);paint.setStyle(android.graphics.Paint.Style.STROKE);paint.setStrokeWidth(3.6f);paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);paint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
            canvas.translate(32,24);canvas.scale(0.50f,0.50f);canvas.translate(-32,-24);
            if("edit".equals(kind)){
                android.graphics.Path p=new android.graphics.Path();p.moveTo(17,36);p.lineTo(21,26);p.lineTo(39,8);p.lineTo(49,18);p.lineTo(31,36);p.lineTo(21,40);p.close();canvas.drawPath(p,paint);
                canvas.drawLine(36,11,46,21,paint);canvas.drawLine(20,26,30,36,paint);canvas.drawLine(14,42,22,40,paint);
            }else{
                canvas.drawLine(17,12,47,12,paint);canvas.drawLine(23,8,41,8,paint);canvas.drawLine(20,15,23,39,paint);canvas.drawLine(44,15,41,39,paint);canvas.drawLine(23,39,41,39,paint);
                canvas.drawLine(29,20,29,34,paint);canvas.drawLine(35,20,35,34,paint);
            }
            canvas.restore();
        }
    }
    void showCalculator(){
        calculatorShown=true;
        calcUnit=0;
        calculatorRoot=column(); calculatorRoot.setBackgroundColor(pale);
        LinearLayout header=row(); header.setBackgroundColor(dark); header.setPadding(dp(12),dp(14),dp(12),dp(14));
        TextView back=text("‹",34,-1,true);back.setGravity(Gravity.CENTER);header.addView(back,new LinearLayout.LayoutParams(dp(40),dp(48)));back.setOnClickListener(v->showHome());
        TextView title=text("Marketim",24,-1,true);header.addView(title); TextView calcTitle=text("  Hesap Makinesi",18,-1,true);header.addView(calcTitle,new LinearLayout.LayoutParams(0,-2,1));calculatorRoot.addView(header);
        ScrollView calculatorScroll=new ScrollView(this);calculatorScroll.setFillViewport(false);calculatorScroll.setVerticalScrollBarEnabled(true);
        LinearLayout body=column();body.setPadding(dp(12),dp(12),dp(12),dp(18));calculatorScroll.addView(body,new ScrollView.LayoutParams(-1,-2));calculatorRoot.addView(calculatorScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout selectors=row();selectors.setGravity(Gravity.CENTER);String[] units={"Gram","Kg","Adet"};TextView[] tabs=new TextView[3];
        for(int i=0;i<3;i++){final int u=i;TextView tab=text(units[i],15,0xFF26352F,true);tab.setGravity(Gravity.CENTER);tab.setPadding(dp(4),dp(12),dp(4),dp(12));tab.setBackground(bg(0xFFE8ECEF,12));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.setMargins(dp(3),0,dp(3),0);selectors.addView(tab,tp);tabs[i]=tab;tab.setOnClickListener(v->{calcUnit=u;for(int j=0;j<3;j++){tabs[j].setBackground(bg(j==u?green:0xFFE8ECEF,12));tabs[j].setTextColor(j==u?-1:0xFF26352F);}calcAmountLabel.setText(u==0?"Miktar (g)":u==1?"Miktar (kg)":"Miktar (adet)");calcAmount.setHint(u==0?"Gram":u==1?"Kg":"Adet");updateCalculator();});}
        tabs[0].setBackground(bg(green,12));tabs[0].setTextColor(-1);body.addView(selectors);
        LinearLayout inputCard=column();inputCard.setBackground(bg(0xFFEAF5EF,16));inputCard.setPadding(dp(10),dp(12),dp(10),dp(12));LinearLayout.LayoutParams icp=new LinearLayout.LayoutParams(-1,-2);icp.topMargin=dp(12);body.addView(inputCard,icp);
        LinearLayout compactInputs=row();compactInputs.setGravity(Gravity.CENTER_VERTICAL);inputCard.addView(compactInputs);
        LinearLayout amountColumn=column();amountColumn.setPadding(0,0,dp(5),0);compactInputs.addView(amountColumn,new LinearLayout.LayoutParams(0,-2,1));
        calcAmountLabel=text("Miktar (g)",14,green,true);amountColumn.addView(calcAmountLabel);
        calcAmount=plainNumberField("Miktar");amountColumn.addView(calcAmount,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout priceColumn=column();priceColumn.setPadding(dp(5),0,0,0);compactInputs.addView(priceColumn,new LinearLayout.LayoutParams(0,-2,1));
        TextView priceLabel=text("Fiyat (TL)",14,green,true);priceColumn.addView(priceLabel);
        calcPrice=plainNumberField("Toplam fiyat");priceColumn.addView(calcPrice,new LinearLayout.LayoutParams(-1,dp(50)));
        calcAmount.addTextChangedListener(calcWatcher());calcPrice.addTextChangedListener(calcWatcher());
        TextView resultsTitle=text("Hesaplanan Fiyatlar",18,-1,true);resultsTitle.setGravity(Gravity.CENTER);resultsTitle.setPadding(dp(8),dp(14),dp(8),dp(14));resultsTitle.setBackground(bg(green,12));LinearLayout.LayoutParams rt=new LinearLayout.LayoutParams(-1,-2);rt.topMargin=dp(14);body.addView(resultsTitle,rt);
        LinearLayout resultCard=column();resultCard.setBackground(bg(-1,16));resultCard.setPadding(dp(10),dp(10),dp(10),dp(10));LinearLayout.LayoutParams rcp=new LinearLayout.LayoutParams(-1,-2);rcp.topMargin=dp(8);body.addView(resultCard,rcp);
        kgResult=resultRow("1 Kg Fiyatı");resultCard.addView(kgResult);gramResult=resultRow("1 Gram Fiyatı");resultCard.addView(gramResult);adetResult=resultRow("1 Adet Fiyatı");resultCard.addView(adetResult);
        LinearLayout bottom=row();bottom.setGravity(Gravity.CENTER);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(16);body.addView(bottom,bp);
        TextView clear=actionButton("Temizle",0xFFE5E9ED,0xFF26352F);TextView copy=actionButton("Sonuçları Kopyala",green,-1);bottom.addView(clear,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams cop=new LinearLayout.LayoutParams(0,dp(54),1);cop.leftMargin=dp(8);bottom.addView(copy,cop);
        clear.setOnClickListener(v->{calcAmount.setText("");calcPrice.setText("");updateCalculator();});copy.setOnClickListener(v->copyCalculatorResults());
        setContentView(calculatorRoot);updateCalculator();
    }
    EditText plainNumberField(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(18);e.setGravity(Gravity.CENTER);e.setInputType(8194);e.setPadding(dp(10),dp(8),dp(10),dp(8));e.setBackground(bg(0xFFFFFFFF,12));return e;}
    TextWatcher calcWatcher(){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){updateCalculator();}public void afterTextChanged(Editable e){}};}
    TextView resultRow(String label){TextView t=text(label+"     —",15,green,true);t.setPadding(dp(8),dp(14),dp(8),dp(14));return t;}
    TextView actionButton(String label,int color,int txt){TextView t=text(label,15,txt,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(color,14));t.setElevation(dp(2));return t;}
    void updateCalculator(){
        if(calcAmount==null||calcPrice==null||kgResult==null)return;double amount=number(calcAmount.getText().toString()),price=number(calcPrice.getText().toString());boolean valid=amount>0&&price>=0&&!calcAmount.getText().toString().trim().isEmpty()&&!calcPrice.getText().toString().trim().isEmpty();
        if(!valid){kgResult.setText("1 Kg Fiyatı     —");gramResult.setText("1 Gram Fiyatı   —");adetResult.setText("1 Adet Fiyatı   —");return;}
        if(calcUnit==0){double grams=amount,kg=grams/1000.0;kgResult.setText("1 Kg Fiyatı     "+money(price/kg)+" TL/kg");gramResult.setText("1 Gram Fiyatı   "+money(price/grams)+" TL/g");adetResult.setText("1 Adet Fiyatı   —");}
        else if(calcUnit==1){double kg=amount,grams=kg*1000.0;kgResult.setText("1 Kg Fiyatı     "+money(price/kg)+" TL/kg");gramResult.setText("1 Gram Fiyatı   "+money(price/grams)+" TL/g");adetResult.setText("1 Adet Fiyatı   —");}
        else{kgResult.setText("1 Kg Fiyatı     —");gramResult.setText("1 Gram Fiyatı   —");adetResult.setText("1 Adet Fiyatı   "+money(price/amount)+" TL/adet");}
    }
    String money(double value){return String.format(Locale.US,"%.2f",value).replace('.',',');}
    void copyCalculatorResults(){String result=kgResult.getText()+"\n"+gramResult.getText()+"\n"+adetResult.getText();android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);clipboard.setPrimaryClip(ClipData.newPlainText("Marketim Hesap",result));Toast.makeText(this,"Sonuçlar kopyalandı",Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(calculatorShown){showHome();}else super.onBackPressed();}
    static class Item{long id;String name,brand,amount,price,store,note;Item(long i,String n,String b,String a,String p,String s,String no){id=i;name=n;brand=b;amount=a;price=p;store=s;note=no;}}
    boolean isWeightAmount(String amount){return amount!=null && amount.trim().toLowerCase(Locale.ROOT).endsWith("kg");}
    double number(String value){try{return Double.parseDouble(value.trim().replace(",","."));}catch(Exception e){return 0;}}
    String fmt(double value){if(Math.abs(value-Math.round(value))<0.0000001)return String.valueOf((long)Math.round(value));return String.format(Locale.US,"%.3f",value).replaceAll("0+$","").replaceAll("\\.$","").replace('.',',');}
    void editItem(Item item){
        LinearLayout form=column();form.setPadding(dp(8),dp(4),dp(8),dp(4));ScrollView sc=new ScrollView(this);sc.addView(form);
        EditText name=field("Ürün adı *"),grams=field("Gram (g)"),kilos=field("Kilogram (kg)"),price=field("Toplam fiyat (TL)"),brand=field("Marka"),store=field("Mağaza / internet sitesi"),note=field("Not");
        grams.setInputType(8194);kilos.setInputType(8194);price.setInputType(8194);
        EditText[] common={name,brand,store};String[] commonLabels={"Ürün adı","Marka","Mağaza"};
        for(int i=0;i<common.length;i++){TextView label=text(commonLabels[i],13,0xFF53645B,true);label.setPadding(dp(2),dp(7),0,dp(3));form.addView(label);common[i].setText(item==null?"":(i==0?item.name:i==1?item.brand:item.store));form.addView(common[i],new LinearLayout.LayoutParams(-1,dp(48)));}
        TextView quantityLabel=text("Miktar",13,0xFF53645B,true);quantityLabel.setPadding(dp(2),dp(10),0,dp(4));form.addView(quantityLabel);
        LinearLayout quantityRow=row();quantityRow.setGravity(Gravity.CENTER_VERTICAL);quantityRow.setPadding(0,dp(2),0,0);quantityRow.addView(grams,new LinearLayout.LayoutParams(0,dp(48),1));View gap=new View(this);quantityRow.addView(gap,new LinearLayout.LayoutParams(dp(10),1));quantityRow.addView(kilos,new LinearLayout.LayoutParams(0,dp(48),1));form.addView(quantityRow,new LinearLayout.LayoutParams(-1,-2));
        TextView priceLabel=text("Toplam fiyat (TL)",13,0xFF53645B,true);priceLabel.setPadding(dp(2),dp(7),0,dp(3));form.addView(priceLabel);form.addView(price,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView noteLabel=text("Not",13,0xFF53645B,true);noteLabel.setPadding(dp(2),dp(7),0,dp(3));form.addView(noteLabel);note.setText(item==null?"":item.note);form.addView(note,new LinearLayout.LayoutParams(-1,dp(48)));
        grams.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){if(s.length()>0 && kilos.length()>0)kilos.setText("");}public void afterTextChanged(Editable e){}});
        kilos.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){if(s.length()>0 && grams.length()>0)grams.setText("");}public void afterTextChanged(Editable e){}});
        if(item!=null){String oldAmount=item.amount==null?"":item.amount.trim().toLowerCase(Locale.ROOT);double kg=0;if(oldAmount.endsWith("kg"))kg=number(oldAmount.substring(0,oldAmount.length()-2));else if(oldAmount.endsWith("g"))kg=number(oldAmount.substring(0,oldAmount.length()-1))/1000.0;else kg=number(oldAmount);if(kg>0)kilos.setText(fmt(kg));double unit=number(item.price);price.setText(fmt(kg*unit));}
        new AlertDialog.Builder(this).setTitle(item==null?"Yeni ürün":"Ürünü düzenle").setView(sc).setNegativeButton("İptal",null).setPositiveButton("Kaydet",(dialog,which)->{
            String n=name.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"Ürün adı gerekli.",Toast.LENGTH_SHORT).show();return;}
            double g=number(grams.getText().toString()),kg=number(kilos.getText().toString());if(g>0&&kg>0){Toast.makeText(this,"Gram veya kilogram alanından yalnızca birini doldur.",Toast.LENGTH_LONG).show();return;}double totalKg=kg>0?kg:g/1000.0;double totalPrice=number(price.getText().toString());if(totalKg<=0){Toast.makeText(this,"Gram veya kilogram miktarını gir.",Toast.LENGTH_SHORT).show();return;}if(totalPrice<0){Toast.makeText(this,"Fiyat geçersiz.",Toast.LENGTH_SHORT).show();return;}
            String[] v={normalizeText(n),normalizeText(brand.getText().toString().trim()),fmt(totalKg)+" kg",fmt(totalPrice/totalKg),normalizeText(store.getText().toString().trim()),normalizeText(note.getText().toString().trim())};if(item==null)db.insert(v);else db.update(item.id,v);hideKeyboard();loadItems(search==null?"":search.getText().toString());Toast.makeText(this,"Ürün kaydedildi",Toast.LENGTH_SHORT).show();
        }).show();
    }
    void hideKeyboard(){try{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),0);}catch(Exception ignored){}}
    static class DB extends SQLiteOpenHelper{DB(Context c){super(c,"urun_hafizam.db",null,1);normalizeExisting();}
        void normalizeExisting(){SQLiteDatabase d=getWritableDatabase();Cursor c=d.rawQuery("SELECT id,name,brand,store,note FROM products",null);while(c.moveToNext()){ContentValues v=new ContentValues();v.put("name",normalizeText(c.getString(1)));v.put("brand",normalizeText(c.getString(2)));v.put("store",normalizeText(c.getString(3)));v.put("note",normalizeText(c.getString(4)));d.update("products",v,"id=?",new String[]{String.valueOf(c.getLong(0))});}c.close();}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,brand TEXT,amount TEXT,price TEXT,store TEXT,note TEXT)");}public void onUpgrade(SQLiteDatabase d,int o,int n){}void insert(String[] v){ContentValues c=cv(v);getWritableDatabase().insert("products",null,c);}void update(long id,String[] v){getWritableDatabase().update("products",cv(v),"id=?",new String[]{""+id});}ContentValues cv(String[] v){ContentValues c=new ContentValues();String[] k={"name","brand","amount","price","store","note"};for(int i=0;i<k.length;i++)c.put(k[i],v[i]);return c;}}
}
