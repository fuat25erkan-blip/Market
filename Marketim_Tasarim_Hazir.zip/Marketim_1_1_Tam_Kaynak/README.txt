MARKETIM - TAM KAYNAK KODU - SURUM 1.2

Bu proje Android telefon kullanilarak GitHub Actions ile APK derlemek icin hazirlanmistir.

OZELLIKLER
- Yenilenmis ana ekran tasarimi: arama, ikonlu Urun Ekle ve Hesap Makinesi
- Urun kartlarinda belirgin kalem ve cop kutusu ikonlu duzenle/sil islemleri
- Fiyatlar TL/kg olarak gosterilir
- Hesap Makinesi: Gram, Kg veya Adet secimi; secilen birime gore miktar girisi
- Hesaplanan fiyat dokumu: kg, gram ve adet (uygulanamayan birimlerde —)
- Hesap makinesinde Temizle ve Sonuclari Kopyala
- Marketim mevcut yesil tasarimi ve sepet simgesi
- Urun ekleme, duzenleme, silme ve arama
- Sutun basliklarina dokunarak siralama
- Sag ustte uc nokta menusu
- Yedekle: Urunleri JSON dosyasi olarak kaydetme
- Yedekten geri yukle: JSON yedegini secip urunleri geri getirme
- Yerel SQLite veritabani

PROJE BILGILERI
- applicationId: com.fuat.urunhafizam
- versionCode: 2
- versionName: 1.1
- minSdk: 23

GITHUB'A YUKLEME
1. ZIP dosyasini telefona indirip cikartin.
2. Cikartilan Marketim_1_1_Tam_Kaynak klasorunu acin.
3. GitHub'daki Market deposunda Add file > Upload files secin.
4. Bu klasorun ICINDEKI dosya ve klasorleri depo kokune yukleyin. Yalnizca ZIP dosyasini depoya koymak yeterli degildir.
5. .github/workflows/build-apk.yml dosyasinin da depo kokunde bulundugundan emin olun. Android/Gradle dosyalariyla birlikte yukleyin.
6. Commit changes yapin.
7. Actions sekmesinden Build Market APK akisinin tamamlanmasini bekleyin.
8. Basarili calisma kaydini acin. Artifacts bolumundeki Market-debug-APK dosyasini indirin.
9. Artifact ZIP'ini telefonda cikartip app-debug.apk dosyasini kurun.

VERI VE KURULUM UYARISI
Bu surum ayni applicationId ile derlenir. Eski uygulamanin uzerine veri kaybetmeden kurulabilmesi icin APK imza sertifikasinin da ayni olmasi gerekir. GitHub Actions debug imzasi onceki derlemeden farkli olabilir.

Eski verileri yeniden gireceginizi belirttiginiz icin: Yeni APK basariyla olusturulup telefonunuza indirildikten sonra, Android imza uyusmazligi nedeniyle uzerine kurulum yapilamazsa eski Marketim uygulamasini kaldirip yeni APK'yi kurabilirsiniz. Bu durumda eski uygulamadaki yerel urun verileri silinir. Yeni uygulamada urunleri yeniden ekleyin.

YEDEKLEME KULLANIMI
- Ana ekranda sag ustteki uc noktaya dokunun.
- Yedekle secenegiyle JSON dosyasini telefonunuzda istediginiz konuma kaydedin.
- Geri yuklemek icin Yedekten geri yukle secenegine dokunup JSON dosyasini secin.
- Geri yukleme mevcut urun listesini yedekteki listeyle degistirir. Islemden once mevcut listenizi yedekleyin.

Bu ZIP kaynak kodudur; hazir APK icermez. APK GitHub Actions ile derlenir.
