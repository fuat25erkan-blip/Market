package com.fuat.urunhafizam;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputFilter;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout list; EditText search; int sortColumn=0; boolean sortAscending=true;
    final int green=0xFF176B50, dark=0xFF12533E, pale=0xFFF2F7F4;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); showHome();}
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(-1);b.setBackground(bg(green,12));return b;}
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setFilters(new InputFilter[]{new InputFilter.AllCaps()});e.setHint(hint);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(bg(0xFFF0F2F1,10));return e;}
    void base(String title){LinearLayout root=column();root.setBackgroundColor(pale);TextView head=text(title,24,-1,true);head.setPadding(dp(18),dp(20),dp(18),dp(20));head.setBackgroundColor(green);root.addView(head);setContentView(root);}
    void showHome(){
        LinearLayout root=column(); root.setBackgroundColor(pale);
        LinearLayout header=column(); header.setPadding(dp(18),dp(16),dp(18),dp(10)); header.setBackgroundColor(0xFFFFFFFF);
        LinearLayout brandRow=row();
        TextView head=text("Marketim",30,green,true); brandRow.addView(head);
        ImageView basket=new ImageView(this); basket.setImageResource(com.fuat.urunhafizam.R.drawable.ic_basket);
        LinearLayout.LayoutParams basketParams=new LinearLayout.LayoutParams(dp(38),dp(38)); basketParams.leftMargin=dp(8); brandRow.addView(basket,basketParams);
        header.addView(brandRow);
        TextView email=text("fuat25erkan@gmail.com",11,0xFF63746B,false); email.setGravity(Gravity.RIGHT); header.addView(email);
        root.addView(header);
        LinearLayout body=column(); body.setPadding(dp(12),dp(12),dp(12),dp(10)); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        search=field("Ürün veya marka ara..."); body.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout actions=row(); actions.setGravity(Gravity.RIGHT); actions.setPadding(0,dp(10),0,dp(10));
        Button add=new Button(this); add.setText("+ Ürün ekle"); add.setAllCaps(false); add.setTextColor(0xFF754500); add.setTextSize(14); add.setPadding(dp(10),0,dp(10),0); add.setBackground(bg(0xFFFFE2A6,12));
        actions.addView(add,new LinearLayout.LayoutParams(-2,dp(42))); body.addView(actions); add.setOnClickListener(v->editItem(null));
        String[] labels={"ÜRÜN","MARKA","MAĞAZA","MİKTAR","FİYAT"};
        LinearLayout headings=row(); headings.setBackground(bg(green,8)); headings.setPadding(dp(2),dp(12),dp(2),dp(12));
        float[] weights={1.15f,1f,1f,0.8f,0.9f};
        for(int i=0;i<labels.length;i++){ final int col=i; TextView t=text(labels[i],12,-1,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(1),0,dp(1),0);headings.addView(t,new LinearLayout.LayoutParams(0,-2,weights[i]));t.setOnClickListener(v->{if(sortColumn==col)sortAscending=!sortAscending;else{sortColumn=col;sortAscending=true;}loadItems(search==null?"":search.getText().toString());}); }
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.bottomMargin=dp(6); body.addView(headings,hp);
        ScrollView vertical=new ScrollView(this); vertical.setFillViewport(false); vertical.setVerticalScrollBarEnabled(true); vertical.setClipToPadding(false);
        list=column(); vertical.addView(list,new ScrollView.LayoutParams(-1,-2)); body.addView(vertical,new LinearLayout.LayoutParams(-1,0,1));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int start,int before,int count){loadItems(s.toString());}public void afterTextChanged(Editable e){}});
        setContentView(root); loadItems("");
    }
    void loadItems(String q){
        if(list==null)return;
        while(list.getChildCount()>0)list.removeViewAt(0);
        String[] order={"name COLLATE NOCASE","brand COLLATE NOCASE","store COLLATE NOCASE","CAST(amount AS REAL)","CAST(price AS REAL)"};
        String direction=sortAscending?" ASC":" DESC";
        Cursor c=db.getReadableDatabase().rawQuery("SELECT * FROM products WHERE name LIKE ? OR brand LIKE ? OR store LIKE ? ORDER BY "+order[sortColumn]+direction+", name COLLATE NOCASE ASC",new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"});
        if(c.getCount()==0){TextView empty=text("Henüz ürün yok. Ürün ekle düğmesine dokun.",14,0xFF607168,false);empty.setPadding(dp(8),dp(20),dp(8),dp(20));list.addView(empty);}
        float[] weights={1.15f,1f,1f,0.8f,0.9f};
        while(c.moveToNext()){
            final Item it=new Item(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6));
            LinearLayout card=column(); card.setBackground(bg(-1,8)); card.setPadding(dp(4),dp(8),dp(4),dp(5));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(6);list.addView(card,cp);
            LinearLayout values=row(); values.setGravity(Gravity.CENTER_VERTICAL); card.addView(values,new LinearLayout.LayoutParams(-1,dp(42)));
            String shownAmount=isWeightAmount(it.amount)?"1 kg":it.amount;
            String[] vals={it.name,it.brand,it.store,shownAmount,it.price.isEmpty()?"—":it.price+" TL"};
            for(int i=0;i<vals.length;i++){TextView t=text(vals[i]==null?"":vals[i],12,i==4?green:0xFF1D3028,i==0||i==4);t.setGravity(Gravity.CENTER);t.setPadding(dp(1),dp(2),dp(1),dp(2));values.addView(t,new LinearLayout.LayoutParams(0,-2,weights[i]));}
            LinearLayout buttons=row(); buttons.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); buttons.setPadding(0,dp(3),0,0);
            Button edit=new Button(this);edit.setText("Düzenle");edit.setAllCaps(false);edit.setTextSize(11);edit.setTextColor(-1);edit.setBackground(bg(0xFF287FE0,8));
            Button del=new Button(this);del.setText("Sil");del.setAllCaps(false);del.setTextSize(11);del.setTextColor(-1);del.setBackground(bg(0xFFD93025,8));
            buttons.addView(edit,new LinearLayout.LayoutParams(dp(78),dp(38))); LinearLayout.LayoutParams delp=new LinearLayout.LayoutParams(dp(58),dp(38));delp.leftMargin=dp(5);buttons.addView(del,delp);card.addView(buttons);
            edit.setOnClickListener(v->editItem(it));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Ürünü sil?").setMessage(it.name+" kaydı silinecek.").setNegativeButton("Vazgeç",null).setPositiveButton("Sil",(d,w)->{db.getWritableDatabase().delete("products","id=?",new String[]{""+it.id});loadItems(search==null?"":search.getText().toString());}).show());
        }c.close();
    }
    static class Item{long id;String name,brand,amount,price,store,note;Item(long i,String n,String b,String a,String p,String s,String no){id=i;name=n;brand=b;amount=a;price=p;store=s;note=no;}}
    boolean isWeightAmount(String amount){return amount!=null && amount.trim().toLowerCase(Locale.ROOT).endsWith("kg");}
    double number(String value){try{return Double.parseDouble(value.trim().replace(",","."));}catch(Exception e){return 0;}}
    String fmt(double value){if(Math.abs(value-Math.round(value))<0.0000001)return String.valueOf((long)Math.round(value));return String.format(Locale.US,"%.3f",value).replaceAll("0+$","").replaceAll("\\.$","").replace('.',',');}
    void editItem(Item item){
        LinearLayout form=column();form.setPadding(dp(8),dp(4),dp(8),dp(4));ScrollView sc=new ScrollView(this);sc.addView(form);
        EditText name=field("Ürün adı *"),grams=field("Gram (g)"),kilos=field("Kilogram (kg)"),price=field("Toplam fiyat (TL)"),brand=field("Marka"),store=field("Mağaza / internet sitesi"),note=field("Not");
        grams.setInputType(8194);kilos.setInputType(8194);price.setInputType(8194);
        EditText[] common={name,brand,store};String[] commonLabels={"Ürün adı","Marka","Mağaza"};
        for(int i=0;i<common.length;i++){TextView label=text(commonLabels[i],13,0xFF53645B,true);label.setPadding(dp(2),dp(7),0,dp(3));form.addView(label);common[i].setText(item==null?"":(i==0?item.name:i==1?item.brand:item.store));form.addView(common[i],new LinearLayout.LayoutParams(-1,dp(48)));}
        LinearLayout quantityRow=row();quantityRow.addView(grams,new LinearLayout.LayoutParams(0,dp(48),1));View gap=new View(this);quantityRow.addView(gap,new LinearLayout.LayoutParams(dp(8),1));quantityRow.addView(kilos,new LinearLayout.LayoutParams(0,dp(48),1));form.addView(quantityRow);
        TextView priceLabel=text("Toplam fiyat (TL)",13,0xFF53645B,true);priceLabel.setPadding(dp(2),dp(7),0,dp(3));form.addView(priceLabel);form.addView(price,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView noteLabel=text("Not",13,0xFF53645B,true);noteLabel.setPadding(dp(2),dp(7),0,dp(3));form.addView(noteLabel);note.setText(item==null?"":item.note);form.addView(note,new LinearLayout.LayoutParams(-1,dp(48)));
        grams.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){if(s.length()>0 && kilos.length()>0)kilos.setText("");}public void afterTextChanged(Editable e){}});
        kilos.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){if(s.length()>0 && grams.length()>0)grams.setText("");}public void afterTextChanged(Editable e){}});
        if(item!=null){String oldAmount=item.amount==null?"":item.amount.trim().toLowerCase(Locale.ROOT);double kg=0;if(oldAmount.endsWith("kg"))kg=number(oldAmount.substring(0,oldAmount.length()-2));else if(oldAmount.endsWith("g"))kg=number(oldAmount.substring(0,oldAmount.length()-1))/1000.0;else kg=number(oldAmount);if(kg>0)kilos.setText(fmt(kg));double unit=number(item.price);price.setText(fmt(kg*unit));}
        new AlertDialog.Builder(this).setTitle(item==null?"Yeni ürün":"Ürünü düzenle").setView(sc).setNegativeButton("İptal",null).setPositiveButton("Kaydet",(dialog,which)->{
            String n=name.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"Ürün adı gerekli.",Toast.LENGTH_SHORT).show();return;}
            double g=number(grams.getText().toString()),kg=number(kilos.getText().toString());if(g>0&&kg>0){Toast.makeText(this,"Gram veya kilogram alanından yalnızca birini doldur.",Toast.LENGTH_LONG).show();return;}double totalKg=kg>0?kg:g/1000.0;double totalPrice=number(price.getText().toString());if(totalKg<=0){Toast.makeText(this,"Gram veya kilogram miktarını gir.",Toast.LENGTH_SHORT).show();return;}if(totalPrice<0){Toast.makeText(this,"Fiyat geçersiz.",Toast.LENGTH_SHORT).show();return;}
            String[] v={n,brand.getText().toString().trim(),fmt(totalKg)+" kg",fmt(totalPrice/totalKg),store.getText().toString().trim(),note.getText().toString().trim()};if(item==null)db.insert(v);else db.update(item.id,v);hideKeyboard();loadItems(search==null?"":search.getText().toString());Toast.makeText(this,"Ürün kaydedildi",Toast.LENGTH_SHORT).show();
        }).show();
    }
    void hideKeyboard(){try{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),0);}catch(Exception ignored){}}
    static class DB extends SQLiteOpenHelper{DB(Context c){super(c,"urun_hafizam.db",null,1);}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,brand TEXT,amount TEXT,price TEXT,store TEXT,note TEXT)");}public void onUpgrade(SQLiteDatabase d,int o,int n){}void insert(String[] v){ContentValues c=cv(v);getWritableDatabase().insert("products",null,c);}void update(long id,String[] v){getWritableDatabase().update("products",cv(v),"id=?",new String[]{""+id});}ContentValues cv(String[] v){ContentValues c=new ContentValues();String[] k={"name","brand","amount","price","store","note"};for(int i=0;i<k.length;i++)c.put(k[i],v[i]);return c;}}
}
