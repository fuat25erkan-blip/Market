ÜRÜN HAFIZAM - Android Studio proje dosyaları

Özellikler:
- İnternet izni istemez; kayıtları cihazdaki SQLite veritabanında saklar.
- Ürün ekleme, düzenleme, silme ve arama.
- Ürün adı, marka, miktar, fiyat, mağaza ve not alanları.

APK oluşturma:
1. Android Studio'yu bilgisayara kurun.
2. Bu ZIP dosyasını çıkarın.
3. Android Studio'da Open ile UrunHafizam klasörünü açın.
4. Gradle eşitlemesinin tamamlanmasını bekleyin.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
6. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

Not: Bu teslim Android Studio kaynak projesidir; bu ortamda Android SDK/Gradle derleyicisi bulunmadığından derlenmiş APK içermez.
